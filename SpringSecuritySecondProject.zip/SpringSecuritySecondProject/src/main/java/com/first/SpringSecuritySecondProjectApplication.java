package com.first;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringSecuritySecondProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringSecuritySecondProjectApplication.class, args);
	}
}
